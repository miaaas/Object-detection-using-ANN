# 5star-7star > 2023-11-05 4:12pm
https://universe.roboflow.com/sa-re0eg/5star-7star

Provided by a Roboflow user
License: CC BY 4.0

